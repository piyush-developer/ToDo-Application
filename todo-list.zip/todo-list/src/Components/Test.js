import React, { Component } from 'react'



export class Test extends Component {

constructor(props) {
    super(props)

    this.state = {
          todotitle: '',
          tododescription: ''
    }
    this.submit=this.submit.bind(this);
}

submit = e => {

        e.preventDefault();
       
                const userDetails = {
                  
                
                    
                    status: 'Pending',
                    title: this.state.todotitle,
                    description: this.state.tododescription
                     
                    
                }
                
                localStorage.setItem('todoData', JSON.stringify(userDetails))

                alert('data added to localStorage')
               
            }
       
 renderingViewApplication = () => {
        return this.state.leaveApplication.map((application, index) => {
            const { App_id, userId, from, to, status } = application
            if(status=='Rejected'|| status=='Approved'){
                var disabled=true
            }
            return (
                <tr key={index}>
                    <td> {index + 1}</td>
                    <td> {from}</td>
                    <td> {to}</td>
                    <td> {status}</td>
                    <td><button className='btn btn-success'disabled={disabled} value={App_id} onClick={this.EditApplication}> Edit</button></td>
                    <td><button className='btn btn-danger' disabled={disabled} value={App_id} onClick={this.DeleteApplication}> Delete</button></td>

                </tr>
            )

        })
    }

    onchange = e =>{
        this.setState({
            [e.target.name]:e.target.value
        })
    }

    render() {
        return (
            <div>
            <tr>
                <td> <input type="text" name='todotitle' value={this.state.todotitle} onChange={this.onchange} placeholder='Title' required/></td>
                <td> <input type="text" name='tododescription' value={this.state.tododescription} onChange={this.onchange} placeholder='Description' required/></td>
             <td><button  className="btn btn-primary" onClick={this.submit}> Add ToDo</button></td>
             </tr>
                <tr>
                
                <td><button  className="btn btn-primary" onClick={this.complete}> Complete</button>&nbsp;&nbsp;</td>
                <td><button  className="btn btn-primary" onClick={this.update}> Edit</button>&nbsp;&nbsp;</td>
                <td><button  className="btn btn-primary" onClick={this.delete}> Delete</button></td>
                
                </tr>

                <center>
                    <table className='table table-hover striped m-5' border='1'>
                        <tr>
                            <th scope='col'>Sr.No </th>
                            <th scope='col'>Title </th>
                            <th scope='col'>Description </th>
                            <th scope='col'>Status</th>
                            <th scope='col'>Action </th>
                            

                        </tr>
                        
                      

                    </table>
                </center>
            </div>
        )
    }
}

export default Test

